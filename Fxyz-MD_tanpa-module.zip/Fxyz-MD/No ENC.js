Pemikiran gua ya, lu punya duit lu punya kuasa
Tapi buat gua engga nyet.

tapi kalo lu mau beli no enc gass : 6281236167286 😁👋