# CATATAN ( NOTE )
Mulai saat ini, script ini tidak akan dilanjutkan lagi, jika ingin menambah sesuatu lebih baik dibuat pribadi aja, malah keren itu lhu punya tapi yang lain kaga jadi lhu bisa jual tu fitur kalo di publik di script ini mungkin kalian akan rugi sendiri, sudah susah-susah bikin code tapi malah dijual Ama yang cuma modal nyomot doang & dibuat konten yt, yutuber untung yang buat kaga, tapi terserah kalian juga kalo mau pull ya tetep saya ACC

Kalo mau jualan normal aja, jangan sampe nipu atau memberi harapan kosong, contohnya "dijual fitur langkah ada storenya 😱", gabaik itu, mau untung boleh tapi jangan sampe merugikan orang lain 

Best Regards

<p align="center">
<img src="https://telegra.ph/file/77c1465cbd7740b7d1e6e.jpg" alt="Fxyz-Md" width="500"/>
</p>
<h1 align="center">Fxyz-MD</h1>
<p align="center">
  <a href="https://github.com/4ksanzz"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Fxyz+Multi+Device;Base+4KSanzz;Give+star+and+forks+this+Repo+:D;Follow+My+Github" alt="UwU">
</p>

---------

# Media Sosial Bot
<p align="center">
  <a href="https://wa.me/6287814698844?text=.menu"><img src="https://img.shields.io/badge/WhatsApp%20Bot-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/>
  <a href="https://chat.whatsapp.com/F4X72ozG9jz48LzVF0y0dt"><img src="https://img.shields.io/badge/WhatsApp%20Grup-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
</p>

---------

# Note
This Script is for everyone, not for Sale. Jika dijual neraka menunggumu brother !

---------

## Untuk Pengguna Windows/rdp

* Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
* Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)

```bash
git clone https://github.com/4ksanzz/Fxyz-MD
cd Fxyz-MD
npm install
```

## For Termux/ubuntu/ssh User

```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
git clone https://github.com/4ksanzz/Fxyz-MD
cd Fxyz-MD
npm install
```

## Recommended Install On Termux

```bash
pkg install yarn
yarn
```

## Installing
```bash
$ node .
```
---------

# Apikey
* Get Apikey zenz on [`Zenz`](https://api.zahwazein.xyz/)

## Creator New
* [`4K Sanzz`](https://github.com/4ksanzz)

```Thanks to all who have participated in the development of this script```


License: [MIT](https://en.wikipedia.org/wiki/MIT_License)