const fs = require('fs')
const chalk = require('chalk')

global.owner = ["6281916851052"] // ganti nomor wa lu
global.bugrup = ["6281916851052"] // ganti nomor wa lu tapi 1 aja

global.ownerName = "Skyy - MD"
global.thumb = fs.readFileSync("./image/thumb.png")
global.ownerNumber = "Skyy - MD"
global.botName = "Skyy - MD"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})